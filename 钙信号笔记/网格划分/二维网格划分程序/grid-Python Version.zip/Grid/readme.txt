1. background_grid   生成背景网格
2. sidegridt  生成边界上的点
3. sideface 边界上的点每两点连起来，并给这个边赋个属性
4. delaunay2d 向内生成全部点
5. npoch 给全部点赋属性
6. draw 可视化
